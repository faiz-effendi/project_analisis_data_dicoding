# Pengaruh beberapa variabel terhadap peminjaman sepeda ✨

## Setup Environment - command prompt
```
mkdir project_akhir
cd project_akhir
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Run Jupyter Notebook
```
jupyter-notebook .
```

## Run Streamlit Dashboard
```
streamlit run ./dashboard/dashboard.py
```